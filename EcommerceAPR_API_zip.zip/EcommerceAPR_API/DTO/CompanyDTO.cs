﻿

namespace EcommerceAPR.DTO
{
    public class CompanyDTO
    {

        public int CompanyId { get; set; }
        public string CompanyName { get; set; }
    }
}
