﻿namespace EcommerceAPR.DTO
{
    public class CategoryDTO
    {

        public string CategoryName { get; set; }
        public string Description { get; set; }
    }
}
