﻿namespace EcommerceAPR.DTO
{
    public class StateDTO
    {
        public int StateId { get; set; }
        public string StateName { get; set; }
    }
}
