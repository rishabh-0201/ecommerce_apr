﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EcommerceAPR.model
{
    public class Product
    {

        [Key]
        public int productId { get; set; }

        public string productName { get; set; }

        public string productDescription {  get; set; }

        [ForeignKey("categoryId")]
        public int categoryId { get; set; }

        public Category category { get; set; }


    }
}
