﻿namespace EcommerceAPR.model
{
    public class Attribute
    {
    }
}
